

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME  </title>
    <link rel="shortcut icon" href="imagens/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="stylesheet" href="../css/menunavegacao.css">
    
    
<style>

form{
background-color:green;    
    
}    

form,button{
    background-color:green;   

}

</style>    

</head>

<body>
<header rel="cabeçalho">        
<h1>BRUNNO.XYZ</h1>
<?php
session_start();
include('verifica_login.php');
?>

<h5>ID:<?php echo $_SESSION['usuario_id'];?></h5>
<h4><a href="logout.php">Sair</a></h4>
<p>                      </p>
</header>

<nav rel="menu de navegaçao do site" class="bg hover-circulo" >

<a href="https://brunno.xyz/" title="HOME"> HOME</a>
<a href="dowloand/pagina-principal" title="">DOWLOAND</a>
<a href="noticias/pagina-principal" title="NOTICIAS">NOTICIAS</a>
<a href="contato/pagina-principal" title="CONTATO">CONTATO</a>
<a href="ajuda/pagina-principal" title="AJUDA">AJUDA</a>





</nav>

     <main rel="conteudo principal">

         <article>

    
   <h1>Pesquisar usuarios</h1>
<form method="POST" action="./pesquisar.php">
    Pesquisar:<input type="text" name="pesquisar" placeholder="PESQUISAR">
    <input type="submit" value="ENVIAR">
</form>

<?php
    $servidor = "127.0.0.1:3306";
    $usuario = "u570383782_brunno50";
    $senha = "Br@96219643";
    $dbname = "u570383782_login";
    //Criar a conexao
    $conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
    
    $pesquisar = $_POST['pesquisar'];
    $result_cursos = "SELECT * FROM usuario WHERE usuario LIKE '%$pesquisar%' LIMIT 5";
    $resultado_cursos = mysqli_query($conn, $result_cursos);
    
    while($rows_cursos = mysqli_fetch_array($resultado_cursos)){
       echo "Usuario: ".$rows_cursos['usuario']."<br>";
       echo "Senha ".$rows_cursos['senha']."<br>";
        echo "ID: ".$rows_cursos['usuario_id']."<br>";
    }
?>




    <p> Meu nome e <strong>Brunno</strong> sou o criador do site que esta em desenvolvimento
        então algumas paginas vão esta escritas 404 erro significa que em breve ela estara
        disponivel para nossos visitantes estarem acessando, ainda
        estamos trabalhando para responsavidade em todos dispositivos por isso
        caso a barra meu esteja com bugs

               
                                           </p>

    <h2>Novidades</h2>

    <p>

               
                                           </p>


        <h2>Ultimas noticias</h2>

            <p> 
                   EM BREVE
        
                        
                                                    </p>


    <h2>Filmes novos</h2>

            <p> 
                   EM BREVE
        
                        
                                                    </p>     
                                                    
    <h2>Dowloands novos</h2>

            <p>  EM BREVE
                        
                                </p>                                             


  
    <aside>
        <h3>Informações:</h3>

        <p>Criador do site: Brunno</p>
    
      
     
        </aside>
        
    
        <p>
            Então é isso! Espero que você tenha gostado do nosso site
            <strong>https://brunno.xyz/</strong>
        </p>
    </article>
    </main>
    <footer>
    <p>Site criado por  Brunno</p>
    </footer>
    </body>
    </html>

 